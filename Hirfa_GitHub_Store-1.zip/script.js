// Hirfa static prototype interactions
const menuButton=document.querySelector('.menu');
const nav=document.querySelector('.nav nav');
if(menuButton&&nav)menuButton.addEventListener('click',()=>nav.classList.toggle('open'));
const filterButtons=document.querySelectorAll('.filter');
filterButtons.forEach(button=>button.addEventListener('click',()=>{
 filterButtons.forEach(b=>b.classList.remove('active'));button.classList.add('active');
 const filter=button.dataset.filter;
 document.querySelectorAll('.product').forEach(card=>card.style.display=(filter==='all'||card.dataset.category===filter)?'':'none');
}));
let basket=[];
const cartList=document.querySelector('#cart-list'),cartEmpty=document.querySelector('#cart-empty');
document.querySelectorAll('.add').forEach(button=>button.addEventListener('click',()=>{
 const name=button.dataset.name; basket.push(name);renderBasket();
 button.textContent='✓ أُضيف';setTimeout(()=>button.textContent='+ أضف للطلب',900);
}));
function renderBasket(){if(!cartList)return;cartList.innerHTML='';basket.forEach((name,i)=>{const li=document.createElement('li');li.textContent=name+' ';const remove=document.createElement('button');remove.textContent='إزالة';remove.className='add';remove.type='button';remove.addEventListener('click',()=>{basket.splice(i,1);renderBasket()});li.appendChild(remove);cartList.appendChild(li)});if(cartEmpty)cartEmpty.style.display=basket.length?'none':'';}
const itemsField=document.querySelector('#items-field');
if(itemsField&&sessionStorage.getItem('hirfaBasket'))itemsField.value=sessionStorage.getItem('hirfaBasket');
if(document.querySelector('.add'))document.querySelectorAll('.add').forEach(b=>b.addEventListener('click',()=>sessionStorage.setItem('hirfaBasket',basket.join('، '))));
const orderForm=document.querySelector('#order-form');
if(orderForm)orderForm.addEventListener('submit',event=>{event.preventDefault();const result=document.querySelector('#form-result');result.textContent='تم تجهيز بيانات الطلب في هذه المعاينة فقط. لم يتم إرسالها أو حفظها. عند ربط الموقع بوسيلة تواصل فعلية، يمكن تفعيل استقبال الطلبات.';orderForm.reset();if(itemsField)itemsField.value='';sessionStorage.removeItem('hirfaBasket');});
